# Cisco Packet Tracer: Multi-LAN Network Design & RIP v2 Routing Project

This project demonstrates the design, configuration, and verification of a **multi-LAN IPv4 network** using Cisco Packet Tracer.  
The network includes two routers, two switches, and eight PCs distributed across two subnets, with routing handled via **RIP v2**.

## 🧭 Objectives

- Build and configure a multi-LAN topology
- Assign IP addresses and validate device connectivity
- Enable dynamic routing between routers using RIP v2
- Add additional hosts and verify subnet scalability
- Document routing behavior and connectivity

## 🖧 Network Topology

- 2 Routers (R1, R2)
- 2 Switches (SW1, SW2)
- 8 PCs across two LANs
- Router-to-router link using a /30 subnet
- RIP v2 for dynamic route exchange

See `Topology/final-topology.png` for the full diagram.

## ⚙️ Key Configurations

### Router Interfaces

- **R1**
  - G0/0 → 10.0.0.1/30
  - G0/1 → 192.168.1.1/24
- **R2**
  - G0/0 → 10.0.0.2/30
  - G0/1 → 192.168.2.1/24

### RIP v2 Configuration

```text
router rip
 version 2
 no auto-summary
 network 10.0.0.0
 network 192.168.1.0
 network 192.168.2.0
```

## 🧪 Connectivity Verification

Connectivity tests were performed to confirm:

- PC → Default gateway reachability
- PC → Remote LAN communication
- Router → Router reachability across the point-to-point link

All tests were successful across all hosts.

See the `Connectivity-Tests/` folder for ping outputs.

## 📡 Routing Verification

Routing behavior was verified with:

- `show ip route`
- `show ip interface brief`
- `show ip protocols`

RIP-learned routes correctly appeared in the routing tables, and all interfaces were up and correctly addressed.

See the `Routing-Verification/` folder for screenshots.

## 🔍 Network Analysis

- **Networks:** 3  
  - 10.0.0.0/30 (router-to-router link)
  - 192.168.1.0/24 (LAN 1)
  - 192.168.2.0/24 (LAN 2)
- **Collision Domains:** ~10 (one per switch port and router interface)
- **Broadcast Domains:** 2 (one per LAN)

## 📄 Documentation & Slides

- Full technical report is located in the `Report/` folder.
- Presentation slides are in the `Presentation/` folder.

## 🏁 Conclusion

This project successfully demonstrates:

- Router and switch configuration
- IPv4 subnetting and gateway assignments
- Dynamic routing with RIP v2
- End-to-end connectivity testing and verification

It serves as a foundation piece for networking and cybersecurity portfolios.